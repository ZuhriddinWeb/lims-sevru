<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// TZ 1.5 — eslatmalarni har kuni ertalab tekshirish
Schedule::command('lims:check-reminders')->dailyAt('07:00');
